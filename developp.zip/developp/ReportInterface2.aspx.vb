﻿
Partial Class ReportInterface2
    Inherits System.Web.UI.Page

End Class
