﻿
Partial Class DataEdit
    Inherits System.Web.UI.UserControl

End Class
