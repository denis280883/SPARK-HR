select * from dbo.rptlists;
